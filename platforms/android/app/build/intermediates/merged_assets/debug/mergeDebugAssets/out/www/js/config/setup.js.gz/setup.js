// App Backend URL
// var base_url = 'https://sipraja.sidoarjokab.go.id';
var base_url = 'https://tes-sipraja.global-inovasi.com';
// var base_url = 'http://192.168.1.20/pemda/public';
var upload_url = base_url + '/index.php/file/upload';
var site_url_image_layanan = base_url + '/assets/images/layanan/';
var site_url_image_pas_foto_ktp = base_url + '/assets/images/pas_foto_ktp/';
var site_url_image_pas_foto_kpk = base_url + '/assets/images/kartu_pencari_kerja/';
var site_url_image_pas_foto_tdp = base_url + '/assets/images/iumk/';
var site_url_image_bukti_bayar_imb = base_url + '/assets/images/bukti_bayar_imb/';
var site_url_image_pindah = base_url + '/assets/images/pendaftar/';
var site_url_image_pas_foto_kua = base_url + '/assets/images/kua/';

var Attachment = Attachment || new Object();

function getPicture(options, params) {
  navigator.camera.getPicture(function cameraSuccess(imageUri) {
    params.onGetImage(imageUri);
    if (imageUri.indexOf('file:///') == -1) {
      imageUri = 'file://' + imageUri;
    }
    movePic(imageUri, params);
  }, function cameraError(error) {}, options);
}

function movePic(file, params) {
  window.resolveLocalFileSystemURL(file, function (entry) {
    var d = new Date();
    var n = d.getTime();
    var newFileName = n + '.jpg';
    if (!params.subdir) {
      params.onSuccess(entry);
      return;
    }
    params.onSuccess(entry);
  }, function () {
    app.dialog.alert('Error get file');
  });
}

function setOptions(srcType) {
  var options = {
    quality: 50,
    destinationType: Camera.DestinationType.FILE_URI,
    sourceType: srcType,
    encodingType: Camera.EncodingType.JPEG,
    mediaType: Camera.MediaType.ALLMEDIA,
    allowEdit: false,
    correctOrientation: true
  }
  return options;
}

Attachment.openCamera = function (params) {
  var srcType = Camera.PictureSourceType.CAMERA;
  var options = setOptions(srcType);
  getPicture(options, params);
}

Attachment.openGallery = function (params) {
  var srcType = Camera.PictureSourceType.PHOTOLIBRARY;
  var options = setOptions(srcType);
  options.targetHeight = 1024;
  options.targetWidth = 1024;
  getPicture(options, params);
}

if (typeof String.prototype.startsWith != 'function') {
  String.prototype.startsWith = function (str) {
    return this.indexOf(str) === 0;
  };
}

function getFilePath(fileUri, successCallback, failedCallback) {
  if (fileUri.startsWith("content://")) {
    window.FilePath.resolveNativePath(fileUri, function (localFileUri) {
      window.resolveLocalFileSystemURL(localFileUri, function (entry) {
        successCallback(entry);
      }, function (e) {
        var drive = 'content://com.android.externalstorage.documents/document/';
        var content = fileUri;
        if (content.startsWith(drive)) {
          var lastPath = content.substring(drive.length, content.length);
          lastPath = lastPath.replace('%3A', '/').replace('%2F', '/');
          var path = 'file:///storage/' + lastPath;
          window.resolveLocalFileSystemURL(path, function (entry) {
            successCallback(entry);
          }, function (ev) { failedCallback({ evt: ev, errCode: 1 }); });
        } else {
          failedCallback({ evt: e, errCode: 2 });
        }
      });
    }, function (e) {
      failedCallback({ evt: e, errCode: 3 });
    });
  } else if (fileUri.startsWith("file://")) {
    window.resolveLocalFileSystemURL(fileUri, function (entry) {
      successCallback(entry);
    }, function (e) {
      failedCallback({ evt: e, errCode: 4 });
    });
  } else {
    failedCallback({ errCode: 5 });
  }
}

Attachment.openFile = function (params) {
  fileChooser.open(function (fileUri) {
    getFilePath(fileUri, params.onSuccess, function (e) {
      app.dialog.alert('Error:' + e.errCode);
    });
  });
}

Attachment.upload = function (fileEntry, mimeType, success, params) {
  var fileURL = fileEntry.toURL();

  if (!success) success = function (response) {
    app.dialog.alert('Upload success. Code = ' + response.status);
  }

  var fail = function (response) {
    app.dialog.alert('An error has occurred: Code = ' + response.error);
  }

  var fileName = fileURL.substr(fileURL.lastIndexOf('/') + 1);
  alert(fileName);return false;
  cordova.plugin.http.uploadFile(encodeURI(upload_url),
    params, null,
    fileURL, fileName,
    success, fail
  );
}

Attachment.download = function (fileName, download_url) {
  var downloader = new download();
  downloader.Initialize({
      fileSystem : 'file:///storage/emulated/0/Download',
      folder: 'Dokumen SIPRAJA',
      success: function () {
        app.dialog.close();
        app.dialog.alert('Download File Selesai di: /Download/Dokumen SIPRAJA/');
      },
      error: function (err) {
        app.dialog.close();
        app.dialog.alert('Terjadi Kesalahan: ' + err);
      }
  });
  downloader.Get(encodeURI(download_url));
}

// Date & Numeric Setup
function padFloor(number)
{
  return (number < 10 ? '0' : '') + number;
}

Date.prototype.toDateFormat = function() {
  let day = padFloor(this.getDate());
  let month = padFloor(this.getMonth() + 1);
  return this.getFullYear() + '-' + month + '-' + day;
}

Date.prototype.toDateIndoFormat = function() {
  let day = padFloor(this.getDate());
  let month = padFloor(this.getMonth() + 1);
  return day + '-' + month + '-' + this.getFullYear();
}

Date.prototype.toTimeFormat = function() {
  let hour = padFloor(this.getHours());
  let minute = padFloor(this.getMinutes());
  let second = padFloor(this.getSeconds());
  return hour + ':' + minute + ':' + second;
}

Date.prototype.toHourFormat = function() {
  let hour = padFloor(this.getHours());
  let minute = padFloor(this.getMinutes());
  return hour + ':' + minute;
}

Date.prototype.addDays = function(days) {
  let date = new Date(this.valueOf());
  date.setDate(date.getDate() + days);
  return date;
}

function toIdrFormat(number)
{
  return new Intl.NumberFormat('id').format(number);
}