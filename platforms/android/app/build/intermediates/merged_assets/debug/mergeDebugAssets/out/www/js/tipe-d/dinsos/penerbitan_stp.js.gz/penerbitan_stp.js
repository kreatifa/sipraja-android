var penerbitan_stp = {
	path: '/tipe-d/penerbitan_stp/',
  url: './pages/tipe-d/dinsos/penerbitan_stp.html',
  name: 'penerbitan_stp',
  on:{
    pageInit: function() {
      var statusselect = app.smartSelect.create({
        el: '.statusselect',
        on: {
          close: function() {
            app.dialog.preloader('Loading...');
            datatables.context[0].ajax.url = site_url_mobile_layanan + '/penerbitan_stp/get_data/' + $$('#statusselect').val();
            $('#datatables').DataTable().ajax.reload(function(json) {
              if (json.data) {
                app.dialog.close();
              } else {
                app.dialog.close();
                app.dialog.alert('Data tidak dapat ditemukan');
              }
            });
          }
        }
      });
      app.dialog.preloader('Loading...');
      var datatables = $('#datatables').DataTable({
        "serverSide": true,
        "ajax": {
          "url": site_url_mobile_layanan + '/penerbitan_stp/get_data/0',
          "data": iamthedoor,
          "type": "GET"
        },
        "columns": [
          { "data": "id" },
          { "data": "kode_transaksi" },
          { "data": "nama_yayasan" },
          { "data": "nama_pemohon" },
          { "data": "status_jabatan" },
          { "data": "telp_pengurus_yayasan" },
          { "data": "bidang_yayasan" },
          { "data": "id" },
        ],
        "initComplete": function(settings, json) {
          app.dialog.close();
          $$('#datatables_length').hide();
          $$('#datatables_filter').hide();
          // $$('#datatables_paginate').hide();
        },
        "rowCallback": function(row, data) {
          var action = '';
          var text = '';

          if (data.status_approval == 0 || data.status_approval == 2) {
            action = data.id + '/edit/';
            text = 'Edit';
          } else if (data.status_approval == 1) {
            action = data.id + '/view/';
            text = 'Lihat';
          }

          $('td:eq(0)', row).html('<a href="/tipe-d/edit_penerbitan_stp/' + action + '" class="button button-small button-fill color-blue">' +
                '<i class="icon f7-icons" style="font-size: 12pt;">pencil_circle_fill</i> ' + text + '</a>');

          if (data.status_approval) {
            var color = '#17A05E';
            if(data.status_approval == 2){
                var status = 'Ditolak';
                var color = '#DE4E42';
            }
            if(data.status_approval == 0){
              var status = 'Menunggu';
              var color = '#FF9800';
            }
            if(data.status_approval == 3){
              var status = 'Diterima';
              var color = '#17A05E';
            }
            if(data.status_approval == 1){
              var status = 'Selesai';
              var color = '#17A05E';
            }
            $('td:eq(7)', row).html('<span style="background-color:'+color+'; padding:5px; border-radius:10px; color:white;">'+status+'</span>');
          }
        }
      });
    }
  }
};

var new_penerbitan_stp = {
  path: '/tipe-d/new_penerbitan_stp/',
  url: './pages/tipe-d/dinsos/new_penerbitan_stp.html',
  name: 'new_penerbitan_stp',
  on:{
    pageInit: function() {
      $$('#nik_pemohon').val(datauser.nik);
      $$('#nama').val(datauser.nama);
      $$('#tempat_lahir').val(datauser.tempat_lahir);
      $$('#tanggal_lahir').val(new Date(datauser.tanggal_lahir).toDateIndoFormat());
      $$('#jenis_kelamin').val(datauser.jenis_kelamin);
      $$('#telepon').val(datauser.no_telp_pendaftar);
      $$('#kecamatan').val(datauser.nama_kec);
      $$('#kelurahan').val(datauser.nama_kel);
      $$('#email').val(datauser.email);
      $$('#alamat').val(datauser.alamat);
      $$('#nama_pemohon').val(datauser.nama);
      $$('#id_kec').val(datauser.kecamatan);
      $$('#id_kel').val(datauser.kode_desa);

      $$('#simpan').on('click', function() {
        app.input.validateInputs('#new_penerbitan_stp');
        if ($$('#new_penerbitan_stp')[0].checkValidity() == true) {
          let ajax_data = [];
          let form_data = app.form.convertToData('#new_penerbitan_stp');
          // keteranganid = [];
          // filecode = [];
          // $('input[name^=keteranganid]').each(function() {
          //   keteranganid.push($(this).val());
          // });
          // $('input[name^=filecode]').each(function() {
          //   filecode.push($(this).val());
          // });
          ajax_data.push(iamthedoor);
          ajax_data.push(form_data);
          // ajax_data.push(keteranganid);

          app.dialog.preloader('Loading...');
          app.request.post(site_url_mobile_layanan + '/penerbitan_stp/create_penerbitan_stp', ajax_data, function(callback) {
            app.dialog.close();
            if (callback) {
              app.dialog.alert('Data Berhasil Diajukan');
              mainView.router.back();
              $('#datatables').DataTable().ajax.reload();
            } else {
              app.dialog.alert(callback.desc);
            }
          }, function() {
            app.dialog.close();
            app.dialog.alert('Data Gagal Diajukan, Mohon Coba Lagi Nanti');
          }, 'json');
        }
      });
    }
  }
};

var edit_penerbitan_stp = {
  path: '/tipe-d/edit_penerbitan_stp/:id/:tipe',
  url: './pages/tipe-d/dinsos/edit_penerbitan_stp.html',
  name: 'edit_penerbitan_stp',
  on:{
    pageInit: function() {
      var id = mainView.router.currentRoute.params.id;
      var tipe = mainView.router.currentRoute.params.tipe;

      if (tipe == 'view') {
        $$('.savebutton').remove();
        $$('#btndeletelayanan').remove();
        $$('.title').html('Lihat Penerbitan STP Yayasan Sosial');

        $('#nama_pemohon').prop('readonly', true);
        $('#status_jabatan').prop('readonly', true);
        $('#nama_yayasan').prop('readonly', true);
        $('#telp_pengurus').prop('readonly', true);
        $('#bidang_yayasan').prop('readonly', true);
        $('#alamat_yayasan').prop('readonly', true);
      } else {
        $$('.title').html('Edit Penerbitan STP Yayasan Sosial');
      }

      app.dialog.preloader('Loading...');
      app.request.post(site_url_mobile_layanan + '/penerbitan_stp/get_id/' + id, iamthedoor, function(callback) {
        app.dialog.close();

        $$('#nik_pemohon').val(callback.stp.nik);
        $$('#nama').val(callback.stp.nama_user);
        $$('#tempat_lahir').val(callback.stp.tempat_lahir);
        $$('#tanggal_lahir').val(new Date(callback.stp.tanggal_lahir).toDateIndoFormat());
        $$('#jenis_kelamin').val(callback.stp.jenis_kelamin);
        $$('#telepon').val(callback.stp.no_telp_pendaftar);
        $$('#kecamatan').val(callback.stp.nama_kecamatan);
        $$('#kelurahan').val(callback.stp.nama_kelurahan);
        $$('#email').val(callback.stp.email);
        $$('#alamat').val(callback.stp.alamat);
        $$('#nama_pemohon').val(callback.stp.nama_pemohon);
        $$('#id_kec').val(callback.stp.id_kec);
        $$('#id_kel').val(callback.stp.id_kel);
        $$('#status_jabatan').val(callback.stp.status_jabatan);
        $$('#nama_yayasan').val(callback.stp.nama_yayasan);
        $$('#telp_pengurus').val(callback.stp.telp_pengurus_yayasan);
        $$('#bidang_yayasan').val(callback.stp.bidang_yayasan);
        $$('#alamat_yayasan').text(callback.stp.alamat_yayasan);

        if (tipe == 'view') {
          print_attachments_view(callback.deskripsi_dokumen, callback.attachments);
        } else {
          print_attachments_edit(callback.deskripsi_dokumen, callback.attachments);
        }

        // callback.deskripsi_dokumen.forEach(function(item) {
        //   console.log(item);
        //   content += '<li data-index="'+counter+'" ><ul><li class="item-content item-input">'+
        //     '<div class="item-inner">'+
        //       '<div class="row">'+
        //         '<div class="col-60">'+
        //           '<div class="item-inner">'+
        //             '<div class="item-input-wrap">'+
        //               '<input id="fileid'+counter+'" class="fileid" type="hidden" name="fileid['+counter+']">'+
        //               '<input class="filecode" id="filecode'+counter+'" type="hidden" readonly="" name="filecode[]" placeholder="">'+
        //               '<input class="fileurl" id="fileurl'+counter+'" type="text"  name="fileurl['+counter+']" placeholder="URL file">'+
        //             '</div>'+
        //           '</div>'+
        //         '</div>'+
        //         '<div class="col-20 preview_files">'+
        //         '</div>'+
        //         '<div class="col-20">'+
        //           '<a id="'+counter+'" onclick="uploadfile(this.id)" class="button button-round button-fill" style="margin-top: 10px;"><i class="f7-icons" style="font-size: 16pt; margin-top: 7px;">folder_fill</i></a>'+
        //         '</div>'+
        //       '</div>'+
        //     '</li>'+
        //     '<li class="item-content item-input">'+
        //       '<div class="item-inner">'+
        //         '<div class="row">'+
        //           '<div class="col-100">'+
        //             '<div class="item-inner">'+
        //               '<div class="item-input-wrap">'+
        //                 '<input type="text" name="keteranganid[]" placeholder="Keterangan File" value="'+item+'">'+
        //               '</div>'+
        //             '</div>'+
        //           '</div>'+
        //         '</div>'+
        //       '</div>'+
        //     '</li></ul></li>';
        //   counter++;
        // });
      }, function() {
        app.dialog.close();
        app.dialog.alert('Data Gagal Diajukan, Mohon Coba Lagi Nanti');
      }, 'json');

      $$('#deletelayanan').on('click', function() {
        app.dialog.preloader('Loading...');
        app.request.post(site_url_mobile_layanan + '/penerbitan_stp/delete_penerbitan_stp/' + id, iamthedoor, function(callback) {
          app.dialog.close();
          if (callback.success) {
            app.dialog.alert('Data Berhasil Dihapus');
            mainView.router.back();
            $('#datatables').DataTable().ajax.reload();
          } else {
            app.dialog.alert(callback.desc);
          }
        }, function() {
          app.dialog.close();
          app.dialog.alert('Data Gagal Dihapus, Mohon Coba Lagi Nanti');
        }, 'json');
      });

      $$('#simpan').on('click', function() {
        app.input.validateInputs('#edit_penerbitan_stp');
        if ($$('#edit_penerbitan_stp')[0].checkValidity() == true) {
          let ajax_data = [];
          let form_data = app.form.convertToData('#edit_penerbitan_stp');
          // keteranganid = [];
          // filecode = [];
          // $('input[name^=keteranganid]').each(function() {
          //   keteranganid.push($(this).val());
          // });
          // $('input[name^=filecode]').each(function() {
          //   filecode.push($(this).val());
          // });
          ajax_data.push(iamthedoor);
          ajax_data.push(form_data);
          // ajax_data.push(keteranganid);

          app.dialog.preloader('Loading...');
          app.request.post(site_url_mobile_layanan + '/penerbitan_stp/update_penerbitan_stp/' + id, ajax_data, function(callback) {
            app.dialog.close();
            if (callback) {
              app.dialog.alert('Data Berhasil Diedit');
              mainView.router.back();
              $('#datatables').DataTable().ajax.reload();
            } else {
              app.dialog.alert(callback.desc);
            }
          }, function() {
            app.dialog.close();
            app.dialog.alert('Data Gagal Diedit, Mohon Coba Lagi Nanti');
          }, 'json');
        }
      });
    }
  }
}

function print_attachments_edit(deskripsi_dokumen, attachments) {
  var content = '';
  let counter = 1;
  let loop = 0;

  deskripsi_dokumen.forEach(function(item) {
    if (attachments[loop] && attachments[loop].desc == item) {
      console.log(attachments[loop]);
      content += '<li data-index="'+counter+'" ><ul><li class="item-content item-input">'+
        '<div class="item-inner">'+
          '<div class="row">'+
            '<div class="col-60">'+
              '<div class="item-inner">'+
                '<div class="item-input-wrap">'+
                  '<input id="fileid'+counter+'" class="fileid" type="hidden" name="fileid['+counter+']" value="'+attachments[loop].id+'">'+
                  '<input class="filecode" id="filecode'+counter+'" type="hidden" readonly="" name="filecode[]" value="'+attachments[loop].code+'">'+
                  '<input class="fileurl" id="fileurl'+counter+'" type="text"  name="fileurl['+counter+']" value="'+attachments[loop].file_actual+'">'+
                '</div>'+
              '</div>'+
            '</div>'+
            '<div class="col-20 preview_files">'+
              '<a id="'+counter+'" onclick="preview_files('+attachments[loop].id+')" class="button button-round button-fill color-orange" style="margin-top: 10px;"><i class="f7-icons" style="font-size: 16pt; margin-top: 7px;">zoom_in</i></a>'+
            '</div>'+
            '<div class="col-20">'+
              '<a id="'+counter+'" onclick="uploadfile(this.id)" class="button button-round button-fill" style="margin-top: 10px;"><i class="f7-icons" style="font-size: 16pt; margin-top: 7px;">folder_fill</i></a>'+
            '</div>'+
          '</div>'+
        '</li>'+
        '<li class="item-content item-input">'+
          '<div class="item-inner">'+
            '<div class="row">'+
              '<div class="col-100">'+
                '<div class="item-inner">'+
                  '<div class="item-input-wrap">'+
                    // '<input type="text" name="keteranganid[]" value="'+attachments[loop].desc+'">'+
                    '<textarea class="resizable" name="keteranganid[]" rows="2">'+attachments[loop].desc+'</textarea>'+
                  '</div>'+
                '</div>'+
              '</div>'+
            '</div>'+
          '</div>'+
        '</li></ul></li>';
    }
    counter++;
    loop++;
  });
  $$('#formupload-wrapper-list').html(content);
}