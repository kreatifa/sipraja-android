var pengangkatan_anak = {
	path: '/tipe-d/pengangkatan_anak/',
  url: './pages/tipe-d/dinsos/pengangkatan_anak.html',
  name: 'pengangkatan_anak',
  on:{
    pageInit: function() {
      var statusselect = app.smartSelect.create({
        el: '.statusselect',
        on: {
          close: function() {
            app.dialog.preloader('Loading...');
            datatables.context[0].ajax.url = site_url_mobile_layanan + '/pengangkatan_anak/get_data/' + $$('#statusselect').val();
            $('#datatables').DataTable().ajax.reload(function(json) {
              if (json.data) {
                app.dialog.close();
              } else {
                app.dialog.close();
                app.dialog.alert('Data tidak dapat ditemukan');
              }
            });
          }
        }
      });

      app.dialog.preloader('Loading...');
      var datatables = $('#datatables').DataTable({
        "serverSide": true,
        "ajax": {
          "url": site_url_mobile_layanan + '/pengangkatan_anak/get_data/0',
          "data": iamthedoor,
          "type": "GET"
        },
        "columns": [
          { "data": "id" },
          { "data": "kode_transaksi" },
          { "data": "nik" },
          { "data": "nama" },
          { "data": "anak_asuh" },
          { "data": "telp" },
          { "data": "status_approval" },
        ],
        "initComplete": function(settings, json) {
          app.dialog.close();
          $$('#datatables_length').hide();
          $$('#datatables_filter').hide();
        },
        "rowCallback": function(row, data) {
          var action = '';
          var text = '';

          if (data.status_approval == 0 || data.status_approval == 2) {
            action = data.id + '/edit/';
            text = 'Edit';
          } else if (data.status_approval == 1) {
            action = data.id + '/view/';
            text = 'Lihat';
          }

          $('td:eq(0)', row).html('<a href="/tipe-d/edit_pengangkatan_anak/' + action + '" class="button button-small button-fill color-blue">' +
                '<i class="icon f7-icons" style="font-size: 12pt;">pencil_circle_fill</i> ' + text + '</a>');

          if (data.status_approval) {
            var color = '#17A05E';
            if(data.status_approval == 2){
              var status = 'Ditolak';
              var color = '#DE4E42';
            }
            if(data.status_approval == 0){
              var status = 'Menunggu';
              var color = '#FF9800';
            }
            if(data.status_approval == 3){
              var status = 'Diterima';
              var color = '#17A05E';
            }
            if(data.status_approval == 1){
              var status = 'Selesai';
              var color = '#17A05E';
            }
            $('td:eq(6)', row).html('<span style="background-color:'+color+'; padding:5px; border-radius:10px; color:white;">'+status+'</span>');
          }
        }
      });
    }
  }
};

var new_pengangkatan_anak = {
  path: '/tipe-d/new_pengangkatan_anak/',
  url: './pages/tipe-d/dinsos/new_pengangkatan_anak.html',
  name: 'new_pengangkatan_anak',
  on:{
    pageInit: function() {
      $$('#nik_pemohon').val(datauser.nik);
      $$('#nama_pemohon').val(datauser.nama);
      $$('#tempat_lahir').val(datauser.tempat_lahir);
      $$('#tanggal_lahir').val(new Date(datauser.tanggal_lahir).toDateIndoFormat());
      $$('#jenis_kelamin').val(datauser.jenis_kelamin);
      $$('#telp_pemohon').val(datauser.no_telp_pendaftar);
      $$('#kec_pemohon').val(datauser.nama_kec);
      $$('#kel_pemohon').val(datauser.nama_kel);
      $$('#alamat_pemohon').val(datauser.alamat);
      $$('#email_pemohon').val(datauser.email);

      $$('#nama').val(datauser.nama);
      $$('#telp').val(datauser.no_telp_pendaftar);

      app.request.post(site_url_mobile_layanan + '/pengangkatan_anak/get_berkas', iamthedoor, function(result) {
        get_berkas(result.berkas);
      }, 'json');

      $$('#simpan').on('click', function() {
        app.input.validateInputs('#new_pengangkatan_anak');
        if ($$('#new_pengangkatan_anak')[0].checkValidity() == true) {
          let ajax_data = [];
          let form_data = app.form.convertToData('#new_pengangkatan_anak');
          // keteranganid = [];
          // filecode = [];
          // $('input[name^=keteranganid]').each(function() {
          //   keteranganid.push($(this).val());
          // });
          // $('input[name^=filecode]').each(function() {
          //   filecode.push($(this).val());
          // });
          ajax_data.push(iamthedoor);
          ajax_data.push(form_data);
          // ajax_data.push(keteranganid);

          app.dialog.preloader('Loading...');
          app.request.post(site_url_mobile_layanan + '/pengangkatan_anak/create_pengangkatan_anak', ajax_data, function(callback) {
            app.dialog.close();
            if (callback) {
              app.dialog.alert('Data Berhasil Disimpan');
              mainView.router.back();
              $('#datatables').DataTable().ajax.reload();
            } else {
              app.dialog.alert(callback.desc);
            }
          }, function() {
            app.dialog.close();
            app.dialog.alert('Data Gagal Disimpan, Mohon Coba Lagi Nanti');
          }, 'json');
        }
      });
    }
  }
};

var edit_pengangkatan_anak = {
  path: '/tipe-d/edit_pengangkatan_anak/:id/:tipe',
  url: './pages/tipe-d/dinsos/edit_pengangkatan_anak.html',
  name: 'edit_pengangkatan_anak',
  on:{
    pageInit: function() {
      var id = mainView.router.currentRoute.params.id;
      var tipe = mainView.router.currentRoute.params.tipe;

      if (tipe == 'view') {
        $$('.savebutton').remove();
        $$('#btndeletelayanan').remove();

        $('.form-group input').prop('readonly', true);
      }

      $$('#nik_pemohon').val(datauser.nik);
      $$('#nama_pemohon').val(datauser.nama);
      $$('#tempat_lahir').val(datauser.tempat_lahir);
      $$('#tanggal_lahir').val(new Date(datauser.tanggal_lahir).toDateIndoFormat());
      $$('#jenis_kelamin').val(datauser.jenis_kelamin);
      $$('#telp_pemohon').val(datauser.no_telp_pendaftar);
      $$('#kec_pemohon').val(datauser.nama_kec);
      $$('#kel_pemohon').val(datauser.nama_kel);
      $$('#alamat_pemohon').val(datauser.alamat);
      $$('#email_pemohon').val(datauser.email);

      app.dialog.preloader('Loading...');
      app.request.post(site_url_mobile_layanan + '/pengangkatan_anak/find/' + id, iamthedoor, function(data) {
        app.dialog.close();

        $$('#nama').val(data.main.nama);
        $$('#anak_asuh').val(data.main.anak_asuh);
        $$('#telp').val(data.main.telp);

        if (tipe == 'view') {
          get_berkas(data.berkas, data.attachments);
        } else {
          get_berkas(data.berkas, data.attachments);
        }
      }, function() {
        app.dialog.close();
        app.dialog.alert('Data Gagal Ditemukan, Mohon Coba Lagi Nanti');
      }, 'json');

      $$('#deletelayanan').on('click', function() {
        app.dialog.preloader('Loading...');
        app.request.post(site_url_mobile_layanan + '/pengangkatan_anak/delete_pengangkatan_anak/' + id, iamthedoor, function(callback) {
          app.dialog.close();
          if (callback.success) {
            app.dialog.alert('Data Berhasil Dihapus');
            mainView.router.back();
            $('#datatables').DataTable().ajax.reload();
          } else {
            app.dialog.alert(callback.desc);
          }
        }, function() {
          app.dialog.close();
          app.dialog.alert('Data Gagal Dihapus, Mohon Coba Lagi Nanti');
        }, 'json');
      });

      $$('#simpan').on('click', function() {
        app.input.validateInputs('#edit_pengangkatan_anak');
        if ($$('#edit_pengangkatan_anak')[0].checkValidity() == true) {
          let form_data = app.form.convertToData('#edit_pengangkatan_anak');
          let filecode = new Array();
          $('.filecode').each((i, el) => filecode.push(el.value));
          let filedesc = new Array();
          $('.filedesc').each((i, el) => filedesc.push(el.value));

          let ajax_data = new Array();
          ajax_data.push(iamthedoor);
          ajax_data.push(form_data);
          ajax_data.push(filecode);
          ajax_data.push(filedesc);

          app.dialog.preloader('Loading...');
          app.request.post(site_url_mobile_layanan + '/pengangkatan_anak/update_pengangkatan_anak/' + id, ajax_data, function(callback) {
            app.dialog.close();
            if (callback) {
              app.dialog.alert('Data Berhasil Disimpan');
              mainView.router.back();
              $('#datatables').DataTable().ajax.reload();
            } else {
              app.dialog.alert(callback.desc);
            }
          }, function() {
            app.dialog.close();
            app.dialog.alert('Data Gagal Disimpan, Mohon Coba Lagi Nanti');
          }, 'json');
        }
      });
    }
  }
}

function get_berkas(berkas, attachments = null) {
  var content = '';
  var counter = 0;

  berkas.forEach(function(item, index) {
    if (Array.isArray(attachments) && attachments[counter] && attachments[counter].desc == item) {
      content += '<li data-index="'+index+'" ><ul>'+
      '<li class="item-content item-input">'+
        '<div class="item-inner">'+
          '<div class="row">'+
            '<div class="col-60">'+
              '<div class="item-inner">'+
                '<div class="item-input-wrap">'+
                  '<input id="fileid'+index+'" class="fileid" type="hidden" name="fileid['+index+']" value="'+attachments[counter].id+'">'+
                  '<input class="filecode" id="filecode'+index+'" type="hidden" readonly="" name="filecode[]" value="'+attachments[counter].code+'">'+
                  '<input class="fileurl" id="fileurl'+index+'" type="text" name="fileurl['+index+']" placeholder="URL file" value="'+attachments[counter].file_actual+'" readonly>'+
                '</div>'+
              '</div>'+
            '</div>'+
            '<div class="col-20 preview_files">'+
              '<a id="'+index+'" onclick="preview_files('+attachments[counter].id+')" class="button button-round button-fill color-orange" style="margin-top: 10px;"><i class="f7-icons" style="font-size: 16pt; margin-top: 7px;">zoom_in</i></a>'+
            '</div>'+
            '<div class="col-20">'+
              '<a id="'+index+'" onclick="uploadfile(this.id)" class="button button-round button-fill" style="margin-top: 10px;"><i class="f7-icons" style="font-size: 16pt; margin-top: 7px;">folder_fill</i></a>'+
            '</div>'+
          '</div>'+
        '</div>'+
      '</li>'+
      '<li class="item-content item-input">'+
        '<div class="item-inner">'+
          '<div class="row">'+
            '<div class="col-100">'+
              '<div class="item-inner">'+
                '<div class="item-input-wrap">'+
                  '<input type="text" class="filedesc" name="filedesc[]" placeholder="Keterangan File" value="'+attachments[counter].desc+'" readonly>'+
                '</div>'+
              '</div>'+
            '</div>'+
          '</div>'+
        '</div>'+
      '</li></ul></li>';

      counter++;
    } else {
      content += '<li data-index="'+index+'" ><ul>'+
      '<li class="item-content item-input">'+
        '<div class="item-inner">'+
          '<div class="row">'+
            '<div class="col-60">'+
              '<div class="item-inner">'+
                '<div class="item-input-wrap">'+
                  '<input id="fileid'+index+'" class="fileid" type="hidden" name="fileid['+index+']">'+
                  '<input class="filecode" id="filecode'+index+'" type="hidden" readonly="" name="filecode[]">'+
                  '<input class="fileurl" id="fileurl'+index+'" type="text" name="fileurl['+index+']" placeholder="URL file" readonly>'+
                '</div>'+
              '</div>'+
            '</div>'+
            '<div class="col-20 preview_files">'+
            '</div>'+
            '<div class="col-20">'+
              '<a id="'+index+'" onclick="uploadfile(this.id)" class="button button-round button-fill" style="margin-top: 10px;"><i class="f7-icons" style="font-size: 16pt; margin-top: 7px;">folder_fill</i></a>'+
            '</div>'+
          '</div>'+
        '</div>'+
      '</li>'+
      '<li class="item-content item-input">'+
        '<div class="item-inner">'+
          '<div class="row">'+
            '<div class="col-100">'+
              '<div class="item-inner">'+
                '<div class="item-input-wrap">'+
                  '<input type="text" class="filedesc" name="filedesc[]" placeholder="Keterangan File" value="'+item+'" readonly>'+
                '</div>'+
              '</div>'+
            '</div>'+
          '</div>'+
        '</div>'+
      '</li></ul></li>';
    }
  });

  $$('#formupload-wrapper-list').html(content);
}
