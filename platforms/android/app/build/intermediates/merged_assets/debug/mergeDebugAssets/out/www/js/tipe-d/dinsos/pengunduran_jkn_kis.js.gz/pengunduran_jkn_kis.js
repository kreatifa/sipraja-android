var pengunduran_jkn_kis = {
	path: '/tipe-d/pengunduran_jkn_kis/',
  url: './pages/tipe-d/dinsos/pengunduran_jkn_kis.html',
  name: 'pengunduran_jkn_kis',
  on:{
    pageInit: function() {
      
    }
  }
};

var new_pengunduran_jkn_kis = {
  path: '/tipe-d/new_pengunduran_jkn_kis/',
  url: './pages/tipe-d/dinsos/new_pengunduran_jkn_kis.html',
  name: 'new_pengunduran_jkn_kis',
  on:{
    pageInit: function() {
      
    }
  }
};

var edit_pengunduran_jkn_kis = {
  path: '/tipe-d/edit_pengunduran_jkn_kis/:id',
  url: './pages/tipe-d/dinsos/edit_pengunduran_jkn_kis.html',
  name: 'edit_pengunduran_jkn_kis',
  on:{
    pageInit: function() {
      var id = mainView.router.currentRoute.params.id;
    }
  }
}