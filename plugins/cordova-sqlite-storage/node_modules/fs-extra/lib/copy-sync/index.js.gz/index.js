'use strict'

module.exports = {
  copySync: require('./copy-sync')
}
