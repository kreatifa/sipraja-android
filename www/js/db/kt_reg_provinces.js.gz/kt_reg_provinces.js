function get_kt_reg_provinces(result =
[
  {
    "id": "11",
    "name": "ACEH"
  },
  {
    "id": "51",
    "name": "BALI"
  },
  {
    "id": "36",
    "name": "BANTEN"
  },
  {
    "id": "17",
    "name": "BENGKULU"
  },
  {
    "id": "34",
    "name": "DAERAH ISTIMEWA YOGYAKARTA"
  },
  {
    "id": "31",
    "name": "DKI JAKARTA"
  },
  {
    "id": "75",
    "name": "GORONTALO"
  },
  {
    "id": "15",
    "name": "JAMBI"
  },
  {
    "id": "32",
    "name": "JAWA BARAT"
  },
  {
    "id": "33",
    "name": "JAWA TENGAH"
  },
  {
    "id": "35",
    "name": "JAWA TIMUR"
  },
  {
    "id": "61",
    "name": "KALIMANTAN BARAT"
  },
  {
    "id": "63",
    "name": "KALIMANTAN SELATAN"
  },
  {
    "id": "62",
    "name": "KALIMANTAN TENGAH"
  },
  {
    "id": "64",
    "name": "KALIMANTAN TIMUR"
  },
  {
    "id": "65",
    "name": "KALIMANTAN UTARA"
  },
  {
    "id": "19",
    "name": "KEPULAUAN BANGKA BELITUNG"
  },
  {
    "id": "21",
    "name": "KEPULAUAN RIAU"
  },
  {
    "id": "18",
    "name": "LAMPUNG"
  },
  {
    "id": "81",
    "name": "MALUKU"
  },
  {
    "id": "82",
    "name": "MALUKU UTARA"
  },
  {
    "id": "52",
    "name": "NUSA TENGGARA BARAT"
  },
  {
    "id": "53",
    "name": "NUSA TENGGARA TIMUR"
  },
  {
    "id": "91",
    "name": "PAPUA"
  },
  {
    "id": "92",
    "name": "PAPUA BARAT"
  },
  {
    "id": "14",
    "name": "RIAU"
  },
  {
    "id": "76",
    "name": "SULAWESI BARAT"
  },
  {
    "id": "73",
    "name": "SULAWESI SELATAN"
  },
  {
    "id": "72",
    "name": "SULAWESI TENGAH"
  },
  {
    "id": "74",
    "name": "SULAWESI TENGGARA"
  },
  {
    "id": "71",
    "name": "SULAWESI UTARA"
  },
  {
    "id": "13",
    "name": "SUMATERA BARAT"
  },
  {
    "id": "16",
    "name": "SUMATERA SELATAN"
  },
  {
    "id": "12",
    "name": "SUMATERA UTARA"
  }
]
) { return result; }