elementtree v0.1.6 - 2014-02-06

* Add support for CData elements. (#14)
  [hermannpencole]

elementtree v0.1.5 - 2012-11-14

* Fix a bug in the find() and findtext() method which could manifest itself
  under some conditions.
  [metagriffin]

elementtree v0.1.4 - 2012-10-15

* Allow user to use namespaced attributes when using find* functions.
  [Andrew Lunny]

elementtree v0.1.3 - 2012-09-21

* Improve the output of text content in the tags (strip unnecessary line break
  characters).

[Darryl Pogue]

elementtree v0.1.2 - 2012-09-04

 * Allow user to pass 'indent' option to ElementTree.write method. If this
   option is specified (e.g. {'indent': 4}). XML will be pretty printed.
   [Darryl Pogue, Tomaz Muraus]

 * Bump sax dependency version.

elementtree v0.1.1 - 2011-09-23

 * Improve special character escaping.
   [Ryan Phillips]

elementtree v0.1.0 - 2011-09-05

 * Initial release.
