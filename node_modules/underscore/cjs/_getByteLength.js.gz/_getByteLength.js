var _shallowProperty = require('./_shallowProperty.js');

// Internal helper to obtain the `byteLength` property of an object.
var getByteLength = _shallowProperty('byteLength');

module.exports = getByteLength;
