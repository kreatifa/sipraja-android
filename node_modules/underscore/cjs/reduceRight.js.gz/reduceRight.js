var _createReduce = require('./_createReduce.js');

// The right-associative version of reduce, also known as `foldr`.
var reduceRight = _createReduce(-1);

module.exports = reduceRight;
