var _createAssigner = require('./_createAssigner.js');
var allKeys = require('./allKeys.js');

// Fill in a given object with default properties.
var defaults = _createAssigner(allKeys, true);

module.exports = defaults;
