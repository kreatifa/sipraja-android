var _tagTester = require('./_tagTester.js');

var isArrayBuffer = _tagTester('ArrayBuffer');

module.exports = isArrayBuffer;
