var index = require('./index.js');
var mixin = require('./mixin.js');

// Default Export

// Add all of the Underscore functions to the wrapper object.
var _ = mixin(index);
// Legacy Node.js API.
_._ = _;

module.exports = _;
