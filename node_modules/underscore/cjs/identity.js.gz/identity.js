// Keep the identity function around for default iteratees.
function identity(value) {
  return value;
}

module.exports = identity;
