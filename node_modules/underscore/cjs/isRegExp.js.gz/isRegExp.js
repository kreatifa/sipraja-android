var _tagTester = require('./_tagTester.js');

var isRegExp = _tagTester('RegExp');

module.exports = isRegExp;
