var _tagTester = require('./_tagTester.js');

var isString = _tagTester('String');

module.exports = isString;
