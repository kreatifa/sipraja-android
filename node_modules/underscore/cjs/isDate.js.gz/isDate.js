var _tagTester = require('./_tagTester.js');

var isDate = _tagTester('Date');

module.exports = isDate;
