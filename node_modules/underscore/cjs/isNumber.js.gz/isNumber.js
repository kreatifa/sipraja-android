var _tagTester = require('./_tagTester.js');

var isNumber = _tagTester('Number');

module.exports = isNumber;
