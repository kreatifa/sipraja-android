var _tagTester = require('./_tagTester.js');

var hasObjectTag = _tagTester('Object');

module.exports = hasObjectTag;
