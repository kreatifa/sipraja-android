var _createPredicateIndexFinder = require('./_createPredicateIndexFinder.js');

// Returns the last index on an array-like that passes a truth test.
var findLastIndex = _createPredicateIndexFinder(-1);

module.exports = findLastIndex;
