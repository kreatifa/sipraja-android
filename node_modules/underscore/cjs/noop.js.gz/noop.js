// Predicate-generating function. Often useful outside of Underscore.
function noop(){}

module.exports = noop;
