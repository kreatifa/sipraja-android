define(['./_tagTester'], function (_tagTester) {

	var hasObjectTag = _tagTester('Object');

	return hasObjectTag;

});
