define(['./_tagTester'], function (_tagTester) {

	var isArrayBuffer = _tagTester('ArrayBuffer');

	return isArrayBuffer;

});
