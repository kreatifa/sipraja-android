define(['./_tagTester'], function (_tagTester) {

	var isError = _tagTester('Error');

	return isError;

});
