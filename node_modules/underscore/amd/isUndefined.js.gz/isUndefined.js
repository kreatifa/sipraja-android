define(function () {

  // Is a given variable undefined?
  function isUndefined(obj) {
    return obj === void 0;
  }

  return isUndefined;

});
