import crypto from 'crypto';
export default function rng() {
  return crypto.randomBytes(16);
}