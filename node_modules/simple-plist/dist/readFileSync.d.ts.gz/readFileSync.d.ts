/// <reference types="node" />
import { PathOrFileDescriptor } from "fs";
export declare function readFileSync<T = unknown>(aFile: PathOrFileDescriptor): T;
