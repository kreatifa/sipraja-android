import { PlistJsObj } from "./types";
export declare function stringify(anObject: PlistJsObj): string;
